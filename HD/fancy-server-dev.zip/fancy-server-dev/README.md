### KOA2快速开发脚手架
前述：
   
    经过了几个koa2开发的web项目之后，发现有很多造轮子的地方，现在也有很多脚手架工具，但是很多都是前端思想，该模板结合java开发经验，将一些常用工具封装起来，使用注解来导出路由，方便下一个项目的开发。
    
    在后续需求变更下，会逐步完善该模板，当前版本连接的postgre，使用mysql的小伙伴可以更改/src/config/db-config.js 中的配置文件，下面会有详细说明。
    
### 项目目录说明
    注：所有的代码文件均放在src目录下，当前版本使用babel支持ES6语法

&emsp;[db_init 【初始化数据库配置】](./db_init) <br>
&emsp;|-- [init.sql](./dbInit/init.sql)<br>
&emsp;[settings 【系统配置】](./settings)<br>
&emsp;|-- [dev.ini 【开发环境】](./settings/dev.ini)<br>
&emsp;|-- [prod.ini 【正式环境】](./settings/prod.ini)<br>
&emsp;|-- [test.ini 【测试环境】](./settings/test.ini)<br>
&emsp;[src 【核心】](./src)<br>
&emsp;|-- [index.js 【入口文件】](./src/index.js)<br>
&emsp;|-- [app 【业务模块】](./src/app)<br>
&emsp;|&emsp;|-- [common 【基础】](./src/app/common)<br>
&emsp;|&emsp;|&emsp;|-- [daily-task.js 【日常任务】](./src/app/common/daily-task.js)<br>
&emsp;|&emsp;|-- [controller 【视图层，主要处理请求参数】](./src/app/controller)<br>
&emsp;|&emsp;|&emsp;|-- ...<br>
&emsp;|&emsp;|-- [dao 【持久层】](./src/app/dao)<br>
&emsp;|&emsp;|&emsp;|-- ...<br>
&emsp;|&emsp;|-- [models 【数据库DO】](./src/app/models)<br>
&emsp;|&emsp;|&emsp;|-- ...<br>
&emsp;|&emsp;|-- [rpc 【远程调用rpc】](./src/app/rpc)<br>
&emsp;|&emsp;|&emsp;|-- [client.example.js 【客户端案例】](./src/app/rpc/client.example.js)<br>
&emsp;|&emsp;|&emsp;|-- [server.js 【服务端】](./src/app/rpc/server.js)<br>
&emsp;|&emsp;|-- [service 【服务层，处理业务数据】](./src/app/service)<br>
&emsp;|&emsp;|&emsp;|-- ...<br>
&emsp;|-- [config 【配置文件】](./src/config)<br>
&emsp;|&emsp;|-- [db-sequelize.js 【连接数据库的Sequelize对象】](./src/config/db-sequelize.js)<br>
&emsp;|&emsp;|-- [env-config.js 【环境配置】](./src/config/env-config.js)<br>
&emsp;|&emsp;|-- [index.js 【暴露rpc和数据库对象】](./src/config/index.js)<br>
&emsp;|&emsp;|-- [logs-config.js 【日志配置】](./src/config/logs-config.js)<br>
&emsp;|&emsp;|-- [rpc-config.js 【rpc配置】](./src/config/rpc-config.js)<br>
&emsp;|&emsp;|-- [secret.json 【加密配置】](./src/config/secret.json)<br>
&emsp;|&emsp;|-- [update-ddl.js 【数据库更新配置】](./src/config/update-ddl.js)<br>
&emsp;|&emsp;|-- [upload-config.json 【上传文件配置】](./src/config/upload-config.json)<br>
&emsp;|-- [lib 【基础包】](./src/lib)<br>
&emsp;|&emsp;|-- [base-controller.js 【视图层基础对象】](./src/lib/base-controller.js)<br>
&emsp;|&emsp;|-- [base-dao.js 【持久层基础对象】](./src/lib/base-dao.js)<br>
&emsp;|&emsp;|-- [base-service.js 【服务层基础对象】](./src/lib/base-service.js)<br>
&emsp;|&emsp;|-- [router-permission 【路由权限配置】](./src/lib/router-permission)<br>
&emsp;|&emsp;|&emsp;|-- ...<br>
&emsp;|-- [middleware 【中间件】](./src/middleware)<br>
&emsp;|&emsp;|-- [index.js 【入口文件】](./src/middleware/index.js)<br>
&emsp;|&emsp;|-- [interceptor.js 【权限拦截器】](./src/middleware/interceptor.js)<br>
&emsp;|&emsp;|-- [permission.js 【权限拦截器】](./src/middleware/permission.js)<br>
&emsp;|&emsp;|-- [router.js 【路由】](./src/middleware/router.js)<br>
&emsp;|&emsp;|-- [rpc-router.js 【rpc路由】](./src/middleware/rpc-router.js)<br>
&emsp;|-- [utils 【工具脚本】](./src/utils)<br>
&emsp;|&emsp;|-- [template-file 【模板文件】](./src/utils/template-file)<br>
&emsp;|&emsp;|&emsp;|-- ...<br>
&emsp;|&emsp;|-- [auto-generate.js 【自动初始化app脚本】](./src/utils/auto-generate.js)<br>
&emsp;|&emsp;|-- [bean-utils.js 【基础公共脚本】](./src/utils/bean-utils.js)<br>
&emsp;|&emsp;|-- [cache-utils.js 【缓存脚本】](./src/utils/cache-utils.js)<br>
&emsp;|&emsp;|-- [common-utils.js 【公共脚本】](./src/utils/common-utils.js)<br>
&emsp;|&emsp;|-- [crypto-utils.js 【加密脚本】](./src/utils/crypto-utils.js)<br>
&emsp;|&emsp;|-- [db-utils.js 【db基于原生脚本】](./src/utils/db-utils.js)<br>
&emsp;|&emsp;|-- [db_query.js 【db基于原生脚本】](./src/utils/db_query.js)<br>
&emsp;|&emsp;|-- [file-utils.js 【文件处理脚本】](./src/utils/file-utils.js)<br>
&emsp;|&emsp;|-- [http-utils.js 【http请求脚本】](./src/utils/http-utils.js)<br>
&emsp;|&emsp;|-- [linux-utils.js 【linux操作脚本】](./src/utils/linux-utils.js)<br>
&emsp;|&emsp;|-- [logs.js 【日志配置脚本】](./src/utils/logs.js)<br>
&emsp;|&emsp;|-- [office-utills.js 【office脚本】](./src/utils/office-utills.js)<br>
&emsp;|&emsp;|-- [status-code.js 【视图层返回状态码脚本】](./src/utils/status-code.js)<br>
&emsp;|&emsp;|-- [table.js 【基于原始sql的表格处理脚本】](./src/utils/table.js)<br>
&emsp;|&emsp;|-- [wechat-utils.js 【企业微信通知脚本（rpc）】](./src/utils/wechat-utils.js)<br>
&emsp;|&emsp;|-- [word-utils.js 【word文件处理脚本】](./src/utils/word-utils.js)<br>
&emsp;|&emsp;|-- [xlsx-utils.js 【xlsx文件处理脚本】](./src/utils/xlsx-utils.js)<br>
&emsp;[test 【单元测试定点调试】](./test)<br>
&emsp;|-- [example.test.js 【用例】](./test/example.test.js)<br>
&emsp;[package.json](./package.json)<br>
&emsp;[pm2.json 【pm2配置】](./pm2.json)<br>
&emsp;[start.js 【入口文件】](./start.js)<br>



### 安装依赖

```
npm install

```

### 启动服务

```bash
# 开发环境启动
npm run dev
或
cnpm run start
# 测试环境启动
npm run beta

# 正式环境启动
npm run prod
```


### 其它

```bash
# 启动单元测试
npm run test

# 代码格式检查并自动修复
npm run lint

# 初始化mvc格式代码目录
npm run gen-db
```


### 开发说明:
- 1.设计数据库
    ```
    注：假设你以设计出设计库
    ```
    ```
        CREATE TABLE "public"."example" (
            "id" serial primary key,
            "status" int2 DEFAULT 1,
            "create_user_id" int4,
            "update_user_id" int4,
            "create_time" timestamp(6) DEFAULT CURRENT_DATE,
            "update_time" timestamp(6) DEFAULT CURRENT_DATE
        )
    ```
        在./src/utils/auto-generate.js内添加：
            gen('example'); // xxx表
        根目录执行：
            npm run gen-db
        会自动在app目录下生成相应的mvc格式代码
- 2.设置路由
    ```
    注：路由的统一前缀在/src/middleware/router.js 中的API_VERSION 属性配置
    ```
    在/src/app/controller文件中进行路由设置：
    ```
        @controller('/example')
        export class UserController {
        	constructor() {}
            @get('/findAll')
            async findAll(ctx) {
                ctx.log.resourceDesc = '查找全部数据';
                const result = await exampleServer.findAll();
                ctx.body = statusCode.SUCCESS_200('查找成功',result);
            }
        }
    ```
        访问：localhost:${prot}/api/example/findAll

### 部署项目
##### 1.安装node:
    mkdir -p software
    cd /usr
    cd /usr/software
	wget https://nodejs.org/dist/v10.9.0/node-v10.9.0-linux-x64.tar.xz
	tar xf  node-v10.9.0-linux-x64.tar.xz 
	rm -rf node-v10.9.0-linux-x64.tar.xz
	mv node-v10.9.0-linux-x64 node-10.9
	ln -s /usr/software/node-10.9/bin/npm   /usr/local/bin/ 
	ln -s /usr/software/node-10.9/bin/node   /usr/local/bin/
	node -v
	npm -v
##### 2. 安装pm2:
    npm install -g pm2
	ln -s /usr/software/node-10.9/bin/pm2 /usr/local/bin/pm2
    pm2 -v
    
##### 3. 编写pm2.json文件：
```
    {
    	apps:[
    		{
    			name: "FWP",
    			script: "start.js",
    			log_date_format: "YYYY-MM-DD HH:mm:ss:S Z",
    			ignore_watch : ["src/logs","src/utils"],
    			watch:true,
    			max_restarts:100
    		}
    	]
    }
```

##### 4.启动pm2 
    在pm2.json目录下执行：
    
        pm2 start pm2.json
