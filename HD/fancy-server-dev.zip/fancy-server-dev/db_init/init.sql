-- 安装插件
create extension postgres_fdw;
-- 创建base服务
create server base_server
	foreign data wrapper postgres_fdw
	options (host '10.1.1.177', port '5432', dbname 'wp_base');
-- 创建连接用户
create user mapping for postgres server base_server
	options(user 'postgres',password 'postgres');
---------------------------- 创建远程同步表---------------------------------------
-- 部门信息表sys_dept
CREATE foreign TABLE "public"."sys_dept" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "pid" int4,
  "dept_name" varchar(255) COLLATE "pg_catalog"."default",
  "wechat_dept_id" int4
)
server base_server
options (schema_name 'public', table_name 'sys_dept', updatable 'false');
COMMENT ON COLUMN "public"."sys_dept"."pid" IS '父级ID';
COMMENT ON COLUMN "public"."sys_dept"."dept_name" IS '部门名称';
COMMENT ON COLUMN "public"."sys_dept"."wechat_dept_id" IS '企业微信中部门的id';

-- 部门用户关联表sys_dept_user_rele
CREATE foreign TABLE "public"."sys_dept_user_rele" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "user_id" int4,
  "dept_id" int4,
  "is_primary" int2 DEFAULT 0
)
server base_server
options (schema_name 'public', table_name 'sys_dept_user_rele', updatable 'false');
COMMENT ON COLUMN "public"."sys_dept_user_rele"."user_id" IS '用户ID';
COMMENT ON COLUMN "public"."sys_dept_user_rele"."dept_id" IS '部门ID';
COMMENT ON COLUMN "public"."sys_dept_user_rele"."is_primary" IS '是否是主要的，1表示主要，0表示次要';

-- 用户信息表auth_user
CREATE foreign TABLE "public"."auth_user" (
  "id" serial,
  "status" int2 NOT NULL DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "username" varchar(225) COLLATE "pg_catalog"."default",
  "password" varchar(255) COLLATE "pg_catalog"."default",
  "nick_name" varchar(225) COLLATE "pg_catalog"."default",
  "avatar" varchar(255) COLLATE "pg_catalog"."default",
  "email" varchar(100) COLLATE "pg_catalog"."default",
  "source" int2 NOT NULL DEFAULT 1,
  "alias" varchar(255) COLLATE "pg_catalog"."default",
  "phone" varchar(20) COLLATE "pg_catalog"."default",
  "wechat_user_id" varchar(100) COLLATE "pg_catalog"."default"
)
server base_server
options (schema_name 'public', table_name 'auth_user', updatable 'false');
COMMENT ON COLUMN "public"."auth_user"."id" IS '主键';
COMMENT ON COLUMN "public"."auth_user"."status" IS '状态值 1可用 0不可用或删除';
COMMENT ON COLUMN "public"."auth_user"."create_user_id" IS '创建用户ID';
COMMENT ON COLUMN "public"."auth_user"."update_user_id" IS '修改用户ID';
COMMENT ON COLUMN "public"."auth_user"."create_time" IS '创建用户时间';
COMMENT ON COLUMN "public"."auth_user"."update_time" IS '修改用户时间';
COMMENT ON COLUMN "public"."auth_user"."username" IS '用户名';
COMMENT ON COLUMN "public"."auth_user"."password" IS '密码';
COMMENT ON COLUMN "public"."auth_user"."nick_name" IS '昵称';
COMMENT ON COLUMN "public"."auth_user"."avatar" IS '头像';
COMMENT ON COLUMN "public"."auth_user"."email" IS '邮箱';
COMMENT ON COLUMN "public"."auth_user"."source" IS '来源 1表示本地 2表示统一登录';
COMMENT ON COLUMN "public"."auth_user"."wechat_user_id" IS '企业微信用户id';

-- 用户--职位信息表 sys_user_info
CREATE foreign TABLE "public"."sys_user_info" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "user_id" int4,
  "posi_id" int4,
  "posi_rank_id" int4,
  "p_posi_rank_id" int4
)
server base_server
options (schema_name 'public', table_name 'sys_user_info', updatable 'false');
COMMENT ON COLUMN "public"."sys_user_info"."user_id" IS '用户ID';
COMMENT ON COLUMN "public"."sys_user_info"."posi_id" IS '职位ID';
COMMENT ON COLUMN "public"."sys_user_info"."posi_rank_id" IS '职级ID';

-- 职级信息表 sys_position_rank
CREATE foreign TABLE "public"."sys_position_rank" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "rank_type" varchar(255) COLLATE "pg_catalog"."default",
  "big_rank" int2,
  "small_rank" int2 DEFAULT 0
)
server base_server
options (schema_name 'public', table_name 'sys_position_rank', updatable 'false');
COMMENT ON COLUMN "public"."sys_position_rank"."rank_type" IS '职级类型';
COMMENT ON COLUMN "public"."sys_position_rank"."big_rank" IS '第一职级';
COMMENT ON COLUMN "public"."sys_position_rank"."small_rank" IS '小职级';

-- 项目-用户关联表 wp_org_user_rele
CREATE foreign TABLE "public"."wp_org_user_rele" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "org_id" int4,
  "user_id" int4,
  "posi_id" int4,
  "posi_rank_id" int4,
  "is_default" int2 DEFAULT 1,
  "p_posi_rank_id" int4
)
server base_server
options (schema_name 'public', table_name 'wp_org_user_rele', updatable 'false');
COMMENT ON COLUMN "public"."wp_org_user_rele"."org_id" IS '项目组ID';
COMMENT ON COLUMN "public"."wp_org_user_rele"."user_id" IS '用户ID';
COMMENT ON COLUMN "public"."wp_org_user_rele"."posi_id" IS '职位ID';
COMMENT ON COLUMN "public"."wp_org_user_rele"."posi_rank_id" IS '职级ID';
COMMENT ON COLUMN "public"."wp_org_user_rele"."is_default" IS '是否默认（与用户信息同步）1表示默认，2表示手动修改过';

-- 职位信息表 sys_position
CREATE foreign TABLE "public"."sys_position" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "posi_group_id" int4,
  "posi_name" varchar(255) COLLATE "pg_catalog"."default",
  "rank_type" varchar(255) COLLATE "pg_catalog"."default"
)
server base_server
options (schema_name 'public', table_name 'sys_position', updatable 'false');
COMMENT ON COLUMN "public"."sys_position"."posi_group_id" IS '职位组ID';
COMMENT ON COLUMN "public"."sys_position"."posi_name" IS '职位名称';
COMMENT ON COLUMN "public"."sys_position"."rank_type" IS '职级类型';

-- 职位组信息表 sys_position_group
CREATE foreign TABLE "public"."sys_position_group" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "posi_group_name" varchar(255) COLLATE "pg_catalog"."default"
)
server base_server
options (schema_name 'public', table_name 'sys_position_group', updatable 'false');
COMMENT ON COLUMN "public"."sys_position_group"."posi_group_name" IS '职位组名称';

-- 项目信息表 wp_org
CREATE foreign TABLE "public"."wp_org" (
  "id" serial,
  "status" int2 NOT NULL DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "name" varchar(255) COLLATE "pg_catalog"."default",
  "type" varchar(255) COLLATE "pg_catalog"."default",
  "pid" int4 DEFAULT 0,
  "name_code" varchar(255) COLLATE "pg_catalog"."default",
  "is_open_report" int2,
  "dept_list" int4[]
)
server base_server
options (schema_name 'public', table_name 'wp_org', updatable 'false');
COMMENT ON COLUMN "public"."wp_org"."id" IS '主键';
COMMENT ON COLUMN "public"."wp_org"."status" IS '状态值 1可用 0不可用或删除';
COMMENT ON COLUMN "public"."wp_org"."create_user_id" IS '创建用户ID';
COMMENT ON COLUMN "public"."wp_org"."update_user_id" IS '修改用户ID';
COMMENT ON COLUMN "public"."wp_org"."create_time" IS '创建用户时间';
COMMENT ON COLUMN "public"."wp_org"."update_time" IS '修改用户时间';
COMMENT ON COLUMN "public"."wp_org"."name" IS '组织名称';
COMMENT ON COLUMN "public"."wp_org"."type" IS '类型';
COMMENT ON COLUMN "public"."wp_org"."pid" IS '父级ID';
COMMENT ON COLUMN "public"."wp_org"."svn_addr" IS 'svn地址';
COMMENT ON COLUMN "public"."wp_org"."git_addr" IS 'git 地址';
COMMENT ON COLUMN "public"."wp_org"."name_code" IS '产品代号';

-- 项目仓库配置 wp_warehouse_config
CREATE foreign TABLE "public"."wp_warehouse_config" (
  "id" serial,
  "status" int2 NOT NULL DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
	"org_id" int4,
	"type" varchar(255) COLLATE "pg_catalog"."default",
  "name" varchar(255) COLLATE "pg_catalog"."default",
  "url" varchar(255) COLLATE "pg_catalog"."default",
  "master" varchar(255) COLLATE "pg_catalog"."default",
  "branch" varchar(255) COLLATE "pg_catalog"."default",
  "branch_rule" text COLLATE "pg_catalog"."default",
  "cache_key" varchar(255) COLLATE "pg_catalog"."default",
	"engine_url" text COLLATE "pg_catalog"."default",
  "code" varchar(255) COLLATE "pg_catalog"."default"
)
server base_server
options (schema_name 'public', table_name 'wp_warehouse_config', updatable 'false');
COMMENT ON COLUMN "public"."wp_warehouse_config"."type" IS '仓库类型';
COMMENT ON COLUMN "public"."wp_warehouse_config"."name" IS '仓库名称';
COMMENT ON COLUMN "public"."wp_warehouse_config"."url" IS '地址';
COMMENT ON COLUMN "public"."wp_warehouse_config"."master" IS '主分支路径';
COMMENT ON COLUMN "public"."wp_warehouse_config"."branch" IS '分支路径';
COMMENT ON COLUMN "public"."wp_warehouse_config"."branch_rule" IS '分支匹配规则';
COMMENT ON COLUMN "public"."wp_warehouse_config"."cache_key" IS '引擎缓存文件名';
COMMENT ON COLUMN "public"."wp_warehouse_config"."engine_url" IS '引擎版本地址';
COMMENT ON COLUMN "public"."wp_warehouse_config"."code" IS 'svn唯一标标识';
-- 版本信息表 wp_version_info
CREATE foreign TABLE "public"."wp_version_info" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "org_id" int4,
  "name" varchar(255) COLLATE "pg_catalog"."default",
  "start_time" timestamp(6),
  "end_time" timestamp(6),
  "notice" text COLLATE "pg_catalog"."default",
  "lifecycle" int2,
  "primary_user_id" int4,
  "primary_nick_name" varchar(255) COLLATE "pg_catalog"."default",
  "milestone_id" int4,
  "version_live_id" int4,
  "version_lifecycle" varchar(255) COLLATE "pg_catalog"."default",
  "is_open_daily" int2,
  "belong_system" varchar(255) COLLATE "pg_catalog"."default"
)
server base_server
options (schema_name 'public', table_name 'wp_version_info', updatable 'false');
COMMENT ON COLUMN "public"."wp_version_info"."id" IS '主键';
COMMENT ON COLUMN "public"."wp_version_info"."status" IS '状态值 1可用 0不可用或删除';
COMMENT ON COLUMN "public"."wp_version_info"."create_user_id" IS '创建用户ID';
COMMENT ON COLUMN "public"."wp_version_info"."update_user_id" IS '修改用户ID';
COMMENT ON COLUMN "public"."wp_version_info"."create_time" IS '创建用户时间';
COMMENT ON COLUMN "public"."wp_version_info"."update_time" IS '修改用户时间';
COMMENT ON COLUMN "public"."wp_version_info"."org_id" IS '组织ID';
COMMENT ON COLUMN "public"."wp_version_info"."name" IS '版本名称';
COMMENT ON COLUMN "public"."wp_version_info"."start_time" IS '版本开始时间';
COMMENT ON COLUMN "public"."wp_version_info"."end_time" IS '版本结束时间';
COMMENT ON COLUMN "public"."wp_version_info"."notice" IS '版本公告';
COMMENT ON COLUMN "public"."wp_version_info"."lifecycle" IS '【v2.0废弃】版本生命周期:1待定2启用3结束';
COMMENT ON COLUMN "public"."wp_version_info"."primary_user_id" IS '【v2.0废弃】版本负责人ID';
COMMENT ON COLUMN "public"."wp_version_info"."primary_nick_name" IS '【v2.0废弃】版本责任人姓名';
COMMENT ON COLUMN "public"."wp_version_info"."milestone_id" IS '所属里程碑ID';
COMMENT ON COLUMN "public"."wp_version_info"."version_live_id" IS '【v2.0废弃】上线阶段子版本库';
COMMENT ON COLUMN "public"."wp_version_info"."version_lifecycle" IS '【v2.0废弃】版本生命周期，PLAN规划期，DESIGN设计期，EXECUTE执行期';
COMMENT ON COLUMN "public"."wp_version_info"."is_open_daily" IS '是否开启日报：1开启，0不开启';


-- 里程碑信息表 wp_milestone
CREATE foreign TABLE "public"."wp_milestone" (
  "id" serial,
  "status" int2 DEFAULT 1,
  "create_user_id" int4,
  "update_user_id" int4,
  "create_time" timestamp(6) DEFAULT CURRENT_DATE,
  "update_time" timestamp(6) DEFAULT CURRENT_DATE,
  "org_id" int4,
  "pid" int4,
  "name" varchar(255) COLLATE "pg_catalog"."default",
  "code" varchar(255) COLLATE "pg_catalog"."default"
)
server base_server
options (schema_name 'public', table_name 'wp_milestone', updatable 'false');
COMMENT ON COLUMN "public"."wp_milestone"."org_id" IS '所属项目组，0表示全部';
COMMENT ON COLUMN "public"."wp_milestone"."pid" IS '父级id';
COMMENT ON COLUMN "public"."wp_milestone"."name" IS '里程碑名称';
COMMENT ON COLUMN "public"."wp_milestone"."code" IS '唯一标识';
COMMENT ON TABLE "public"."wp_milestone" IS '里程碑表';



------------------------------config--------------------------
-- 查看server:
 select * from pg_foreign_server;
-- 查看用户
 select * from pg_user_mappings;
