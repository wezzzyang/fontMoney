import router from './router';
import rpcRouter from './rpc-router';
import permission from './permission';
import interceptor from './interceptor';
const cors = require('koa2-cors');
/**
* @idemon: 创建与 2019/5/28
* @auther: 杜宇 demonduyu@163.com
* @function:
*/
module.exports = (app) => {
  // 使用跨域
  // app.use(error());
  app.use(cors({
    // origin: function (ctx) {
    //     if (ctx.url === '/api') {
    //         return "*"; // 允许来自所有域名请求
    //     }
    //     return 'http://localhost:8600'; // 这样就能只允许 http://localhost:8080 这个域名的请求了
    // },
    exposeHeaders: ['WWW-Authenticate', 'Server-Authorization'],
    maxAge: 5,
    credentials: true,
    allowMethods: ['GET', 'POST', 'DELETE'],
    allowHeaders: ['Content-Type', 'Authorization', 'Accept']
  }));
  app.use(interceptor());
  app.use(permission());
  router(app); // 加载路由中间件--放到最後
  rpcRouter(app); // rpc
};
