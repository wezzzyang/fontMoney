/**
 * Created by dy on 2020/7/20
 */

import { HproseRpc } from '../lib/router-permission';
import {resolve} from "path";
const dir = path => resolve(__dirname, path);



export default (app) => {
  const rpcPath = dir('../app/rpc/');
  let hproseRpc = new HproseRpc(app, rpcPath);
  hproseRpc.init();
};
