/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { wpOrgUserReleDO } from '../models/wp-org-user-rele';
const wpOrgUserReleModel = dbSequelize.import('./../models/wp-org-user-rele');
wpOrgUserReleModel.sync({ force: false });
class WpOrgUserReleDao extends BaseDao {
  constructor() {
    super(wpOrgUserReleModel, wpOrgUserReleDO);
  }

}

export default new WpOrgUserReleDao();