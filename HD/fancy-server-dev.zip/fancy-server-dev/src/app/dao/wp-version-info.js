/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { wpVersionInfoDO } from '../models/wp-version-info';
const wpVersionInfoModel = dbSequelize.import('./../models/wp-version-info');
wpVersionInfoModel.sync({ force: false });
class WpVersionInfoDao extends BaseDao {
  constructor() {
    super(wpVersionInfoModel, wpVersionInfoDO);
  }

}

export default new WpVersionInfoDao();