/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { sysDeptUserReleDO } from '../models/sys-dept-user-rele';
const sysDeptUserReleModel = dbSequelize.import('./../models/sys-dept-user-rele');
sysDeptUserReleModel.sync({ force: false });
class SysDeptUserReleDao extends BaseDao {
  constructor() {
    super(sysDeptUserReleModel, sysDeptUserReleDO);
  }

}

export default new SysDeptUserReleDao();