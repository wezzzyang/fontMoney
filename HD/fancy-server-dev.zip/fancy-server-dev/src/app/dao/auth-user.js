/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { authUserDO } from '../models/auth-user';
const authUserModel = dbSequelize.import('./../models/auth-user');
authUserModel.sync({ force: false });
class AuthUserDao extends BaseDao {
  constructor() {
    super(authUserModel, authUserDO);
  }

}

export default new AuthUserDao();