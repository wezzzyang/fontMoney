/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { sysPositionDO } from '../models/sys-position';
const sysPositionModel = dbSequelize.import('./../models/sys-position');
sysPositionModel.sync({ force: false });
class SysPositionDao extends BaseDao {
  constructor() {
    super(sysPositionModel, sysPositionDO);
  }

}

export default new SysPositionDao();