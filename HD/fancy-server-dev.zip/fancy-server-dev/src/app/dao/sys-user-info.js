/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { sysUserInfoDO } from '../models/sys-user-info';
const sysUserInfoModel = dbSequelize.import('./../models/sys-user-info');
sysUserInfoModel.sync({ force: false });
class SysUserInfoDao extends BaseDao {
  constructor() {
    super(sysUserInfoModel, sysUserInfoDO);
  }

}

export default new SysUserInfoDao();