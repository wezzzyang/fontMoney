/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { sysDeptDO } from '../models/sys-dept';
const sysDeptModel = dbSequelize.import('./../models/sys-dept');
sysDeptModel.sync({ force: false });
class SysDeptDao extends BaseDao {
  constructor() {
    super(sysDeptModel, sysDeptDO);
  }

}

export default new SysDeptDao();