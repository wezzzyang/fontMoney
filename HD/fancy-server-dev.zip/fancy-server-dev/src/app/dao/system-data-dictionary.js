/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { systemDataDictionaryDO } from '../models/system-data-dictionary';
const systemDataDictionaryModel = dbSequelize.import('./../models/system-data-dictionary');
systemDataDictionaryModel.sync({ force: false });
class SystemDataDictionaryDao extends BaseDao {
  constructor() {
    super(systemDataDictionaryModel, systemDataDictionaryDO);
  }

}

export default new SystemDataDictionaryDao();