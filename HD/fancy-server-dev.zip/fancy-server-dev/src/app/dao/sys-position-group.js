/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { sysPositionGroupDO } from '../models/sys-position-group';
const sysPositionGroupModel = dbSequelize.import('./../models/sys-position-group');
sysPositionGroupModel.sync({ force: false });
class SysPositionGroupDao extends BaseDao {
  constructor() {
    super(sysPositionGroupModel, sysPositionGroupDO);
  }

}

export default new SysPositionGroupDao();