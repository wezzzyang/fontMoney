/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { sysPositionRankDO } from '../models/sys-position-rank';
const sysPositionRankModel = dbSequelize.import('./../models/sys-position-rank');
sysPositionRankModel.sync({ force: false });
class SysPositionRankDao extends BaseDao {
  constructor() {
    super(sysPositionRankModel, sysPositionRankDO);
  }

}

export default new SysPositionRankDao();