/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { wpMilestoneDO } from '../models/wp-milestone';
const wpMilestoneModel = dbSequelize.import('./../models/wp-milestone');
wpMilestoneModel.sync({ force: false });
class WpMilestoneDao extends BaseDao {
  constructor() {
    super(wpMilestoneModel, wpMilestoneDO);
  }

}

export default new WpMilestoneDao();
