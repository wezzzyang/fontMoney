/**
* 由模板自动生成
*/
import { dbSequelize } from '../../config';
import BaseDao from '../../lib/base-dao';
import { wpOrgDO } from '../models/wp-org';
const wpOrgModel = dbSequelize.import('./../models/wp-org');
wpOrgModel.sync({ force: false });
class WpOrgDao extends BaseDao {
  constructor() {
    super(wpOrgModel, wpOrgDO);
  }

}

export default new WpOrgDao();