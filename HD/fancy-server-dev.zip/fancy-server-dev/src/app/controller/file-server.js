const formidable = require('formidable');
const fs = require('fs');
const path = require('path');
import { wpEnv } from '../../config/env-config';
const uuid = require('node-uuid');
import { controller, get, post, put, del } from '../../lib/router-permission';
import statusCode from '../../utils/status-code';
import fileUtils from '../../utils/file-utils';
import uploadConfig from '../../config/upload-config.json';
const crypto = require('crypto');
/**
* @idemon: 创建与 2019/6/12
* @auther: 杜宇 demonduyu@163.com
* @function: 文件-图片上传下载接口
*/
@controller('/file/server')
export class FileServiceController {
  @post('/uploadImage/:orgId')
  async uploadImage(ctx) {
    const orgId = ctx.params.orgId;
    ctx.log.resourceDesc = '上传图片';
    const group = `/version/${orgId}/` || `/${orgId}/`;
    //图片存放目录
    const imageDir = wpEnv.imageDir + group;
    //上传临时目录
    const tmpDir = wpEnv.tmpDir + '/' + orgId + '/';
    await fileUtils.createDirectoryAbsolute(imageDir);
    await fileUtils.createDirectoryAbsolute(tmpDir);
    const form = new formidable.IncomingForm();
    form.encoding = 'utf-8';
    form.uploadDir = tmpDir;// 上传文件的保存路径
    // form.multiples=true; // 允许多个图片上传
    form.keepExtensions = true;// 保存扩展名
    // //文件大小限制，默认10MB
    form.maxFieldsSize = 10 * 1024 * 1024;
    form.maxFileSize = 10 * 1024 * 1024;
    // form.maxFileSize =   1024;
    /**
         * fields 表单中的其他属性
         * files  文件集合
         */
    const param = ctx.request.query;
    await uploadImageOne(ctx, form, imageDir, group, param.source);
  }

  @post('/uploadFile/:orgId')
  async uploadFile(ctx) {
    ctx.log.resourceDesc = '上传文件';
    const form = new formidable.IncomingForm();
    const parse = wrapfunc(form.parse.bind(form));
    const rename = wrapfunc(fs.rename);
    const copyfile = wrapfunc(fs.copyFile);
    const [err, fields, files] = await parse(ctx.req);
    if (err) {
      ctx.body = statusCode.ERROR_AOTU(500, err);
      return;
    }
    const f = files.file;
    const orgId = ctx.params.orgId;
    const dir = `${wpEnv.uploadDir}/${orgId}/`;
    await fileUtils.createDirectoryAbsolute(dir);
    if (!f) {
      ctx.body = statusCode.ERROR_AOTU(500, 'no file');
      return;
    }
    const ext = f.name.split('.').pop();
    let newname = f.path.split('_').pop() + '.' + ext;
    newname = f.name;
    const fileMd5 = await makeMd5(f.path);
    const result = await fsRename(f.path, dir + fileMd5);
    if (result.flag) {
      ctx.body = { code: 200, filename: newname, fileurl: `${orgId}/${fileMd5}` };
    } else {
      ctx.body = statusCode.ERROR_AOTU(500, result.err);
    }
  }

  @get('/downloadFile/:filename/:fileurl/:orgid')
  async downloadFile(ctx) {
    const filename = ctx.params.filename;
    let data = await fileUtils.readFileToBuffer(`${wpEnv.uploadDir}/${ctx.params.orgid}/${ctx.params.fileurl}`, true);
    let realName = filename.split('.').slice(0, filename.split('.').length - 1).join('.');
    realName = encodeURI(realName, 'iso8859-1');
    ctx.set('Content-disposition', 'attachment;filename=' + realName.toString() + '.' + ctx.params.filename.split('.')[filename.split('.').length - 1]);
    ctx.body = data;
  }

  // 获取nginx代理路径地址
  @get('/getThumbsUrl')
  async getThumbsUrl(ctx) {
    let result = {
      image: wpEnv.uploadUrl,
      video: wpEnv.uploadUrl
    };
    ctx.body = { code: 200, data: result };
  }
  // 获取上传文件配置文件
  @get('/getUploadConfig')
  async getUploadConfig(ctx) {
    ctx.body = { code: 200, data: uploadConfig };
  }
}

async function makeMd5(url) {
  return new Promise((reslove) => {
    const md5sum = crypto.createHash('md5');
    const stream = fs.createReadStream(url);
    stream.on('data', function(chunk) {
      md5sum.update(chunk);
    });
    stream.on('end', function() {
      const fileMd5 = md5sum.digest('hex');
      reslove(fileMd5);
    });
  });
}

async function fsRename(path, filename) {
  return new Promise((resolve, reject) => {
    const readStream = fs.createReadStream(path);
    const writeStream = fs.createWriteStream(filename);
    readStream.pipe(writeStream);
    readStream.on('end', function(err) {
      if (err) {
        reject({ 'flag': false, 'err': err });
      }
      fs.unlinkSync(path);
      resolve({ 'flag': true, 'err': '' });
    });
  });
}

function wrapfunc(func) {
  return function() {
    return new Promise(r =>{
      function callback() {
        r(arguments);
      }
      func(...arguments, callback);
    });
  };
}

/**
 * 上传一张图片
 * @param ctx
 * @param form
 * @param imageDir
 * @param group
 * @returns {Promise}
 */
async function uploadImageOne(ctx, form, imageDir, group, source) {
  return new Promise(resolve => {
    form.parse(ctx.req, (err, fields, files) => {
      //图片完整路径
      if (err) {
        ctx.body = statusCode.ERROR_AOTU(403, err.stack);
        resolve();
        return;
      }
      // 图片类型校验
      const allowed = ['.jpg', '.gif', '.png', '.jpeg', 'image/png'];
      const file = source === 'CKEditor' ? files.upload : files.file;
      const seat = file.name.lastIndexOf('.');
      // 截取文件扩展名
      const extension = seat !== -1 ? file.name.substring(seat).toLowerCase() : false;
      // true表示上传的图片文件
      const verifyFile1 = allowed.indexOf(extension) === -1;
      // true表示上传的图片流
      const verifyFile2 = allowed.indexOf(file.type) === -1;
      if (verifyFile1 && verifyFile2) {
        ctx.body = statusCode.ERROR_403('图片类型校验异常,只能上传jpg|gif|png|jpeg格式的图片');
        resolve();
        return;
      }
      const newFileName = uuid.v1() + (extension || '.jpg');
      const imagePath = path.resolve(imageDir, newFileName);
      //将临时目录中的图片移动到图片存放目录下
      fs.rename(file.path, imagePath, function(err) {
        if (err) {
          ctx.body = statusCode.ERROR_AOTU(500, err.stack);
          resolve();
          return;
        }
        const imageUrl = wpEnv.imageUrl + group + newFileName;
        ctx.body = {
          code: 200,
          msg: '上传成功',
          data: { 'imageUrl': imageUrl },
          fileName: newFileName,
          uploaded: 1,
          url: imageUrl
        };
        resolve();
      });
    });
  });
}
