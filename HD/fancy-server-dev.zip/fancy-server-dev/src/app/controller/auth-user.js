import { controller, get, post, put, del, permission, login, nativeLogin } from '../../lib/router-permission';
import authUserService from '../service/auth-user';
import statusCode from '../../utils/status-code';
@controller('/auth/user')
export class AuthUserController {
  @get('/findAll')
  async findAll(ctx) {
    ctx.log.resourceDesc = '查找全部数据';
    const result = await authUserService.findAll();
    ctx.body = statusCode.SUCCESS_200('查找成功', result);
  }
  @get('/findById/:id')
  async findById(ctx) {
    ctx.log.resourceDesc = '根据id查找数据';
    const result = await authUserService.findById(ctx.params.id);
    ctx.body = statusCode.SUCCESS_200('查找成功', result);
  }
  // vuex获取用户信息
  @get('/getUserBaseById/:id')
  async getUserInfo(ctx) {
    ctx.log.resourceDesc = '获取用户信息';
    const result = await authUserService.getUserBaseById(ctx.params.id);
    ctx.body = statusCode.SUCCESS_200('登录成功', result);
  }
  @post('/login/getDevUserToken/:id')
  async getDevUserToken(ctx) {
    ctx.log.resourceDesc = '测试登录操作';
    const user = await authUserService.getDevUserToken(ctx.params.id);
    ctx.body = statusCode.SUCCESS_200('测试成功', user);
  }
  @post('/')
  async create(ctx) {
    ctx.log.resourceDesc = '新增数据';
    if (!ctx.user) throw statusCode.ERROR_501('用户未登录');
    const result = await authUserService.create(ctx.request.body);
    ctx.body = statusCode.SUCCESS_200('新增成功', result);
  }
  @put('/')
  async update(ctx) {
    ctx.log.resourceDesc = '修改数据';
    if (!ctx.user) throw statusCode.ERROR_501('用户未登录');
    const result = await authUserService.updateById(ctx.request.body);
    ctx.body = statusCode.SUCCESS_200('修改成功', result);
  }
  @del('/')
  async delete(ctx) {
    ctx.log.resourceDesc = '逻辑删除数据';
    if (!ctx.user) throw statusCode.ERROR_501('用户未登录');
    const result = await authUserService.logicDeleteByIdToUserId(ctx.request.body.id, ctx.user);
    ctx.body = statusCode.SUCCESS_200('删除成功', result);
  }
  // 解析token
  @get('/parseToken')
  async getUserParse(ctx) {
    ctx.log.resourceDesc = '根据token解析用户信息';
    let userInfo = undefined;
    if (ctx.user && ctx.user.id) {
      userInfo = { ...ctx.user };
    } else {
      // 判断是否是第三方验证
      const token = ctx.request.query.token;
      userInfo = await authUserService.handelToken(token);
    }
    // 从新查找用户的头像和花名信息
    // 封装权限信息
    await authUserService.packagePermissionByUser(userInfo);
    userInfo.serverEnv = ctx.wpEnv.env;
    userInfo.loginIp = ctx.wpEnv.loginIp;
    ctx.body = statusCode.SUCCESS_200('查询成功', userInfo);
  }
  // 本地登录
  @post('/login/native')
  async loginNative(ctx) {
    ctx.log.resourceDesc = '本地登录操作';
    const data = ctx.request.body;
    const user = await authUserService.loginNative(data.username, data.password);
    user.serverEnv = ctx.wpEnv.env;
    user.loginIp = ctx.wpEnv.loginIp;
    ctx.body = statusCode.SUCCESS_200('登录成功', user);
  }
  // 第三方登录接口
  @post('/login/other')
  async loginOther(ctx) {
    const token = ctx.request.body.token;
    ctx.response.status = 200;
    const result = await authUserService.loginOther(token);
    result.serverEnv = ctx.wpEnv.env;
    result.loginIp = ctx.wpEnv.loginIp;
    ctx.body = statusCode.SUCCESS_200('登录成功', result);
  }
}
