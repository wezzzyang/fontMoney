/**
* @idemon: 创建与 2019/7/24
* @auther: 杜宇 demonduyu@163.com
* @function: 用于暴露一些公共的方法
*/
import { controller, get, post, put, del } from '../../lib/router-permission';
import {
  apiDescription, // API接口说明
  apiRequestMapping, // API映射地址
  apiResponse, // API响应请求
  pathParameter, // 路径后面的参数
  queryParameter, // url后缀参数
  bodyParameter // body里面的参数
} from 'swagger-decorator';
import statusCode from '../../utils/status-code';
import cache from '../../utils/cache-utils';
import commonUtils from '../../utils/common-utils';
import { wpEnv } from '../../config/env-config.js';
import httpUtils from '../../utils/http-utils.js';
const beanUtils = require('../../utils/bean-utils');

@controller('/wp/common')
export class CommonController {
  @apiRequestMapping('get', '/wp/common/clearCache')
  @apiDescription('清楚系统缓存数据')
  @get('/clearCache')
  async clearCache(ctx) {
    ctx.log.resourceDesc = '清楚系统缓存数据';
    cache.clearAll();
    ctx.body = statusCode.SUCCESS_200('清楚缓存成功');
  }

  @apiRequestMapping('get', '/wp/common/clearCacheByKey/:key')
  @pathParameter({ name: 'key', description: '缓存的key值', type: 'string' })
  @apiDescription('清楚系统缓存数据')
  @get('/clearCacheByKey/:key')
  async clearCacheByKey(ctx) {
    ctx.log.resourceDesc = '清楚指定KEY缓存数据';
    cache.delete(ctx.params.key);
    ctx.body = statusCode.SUCCESS_200('清楚缓存成功');
  }
  
  @apiRequestMapping('get', '/wp/common/findOneByKey/:key')
  @pathParameter({ name: 'key', description: '缓存的key值', type: 'string' })
  @apiDescription('查找指定KEY缓存数据')
  @get('/findOneByKey/:key')
  async findOneByKey(ctx) {
    ctx.log.resourceDesc = '查找指定KEY缓存数据';
    let result = await cache.get(ctx.params.key);
    ctx.body = statusCode.SUCCESS_200('查找成功', result);
  }
  
  @apiRequestMapping('get', '/wp/common/findAllByCacheKey')
  @apiDescription('获取所有缓存Key列表')
  @get('/findAllByCacheKey')
  async findAllByCacheKey(ctx) {
    ctx.log.resourceDesc = '获取所有缓存Key列表';
    ctx.body = statusCode.SUCCESS_200('查找成功', cache.getKeys());
  }
  
  @apiRequestMapping('get', '/wp/common/findAllByCacheKeyAndSize')
  @apiDescription('获取所有缓存Key列表和每个key所占大小')
  @get('/findAllByCacheKeyAndSize')
  async findAllByCacheKeyAndSize(ctx) {
    ctx.log.resourceDesc = '获取所有缓存Key列表和每个key所占大小';
    console.log('获取所有缓存Key列表和每个key所占大小', cache.getKeys(), typeof cache.getKeys());
    let result = [];
    for (let key of cache.getKeys()) {
      let val = await cache.get(key);
      if (typeof val !== 'string') {
        val = JSON.stringify(val);
      }
      result.push({
        key: key,
        size: commonUtils.bytesToSize(Buffer.from(val).length)
      });
    }
    ctx.body = statusCode.SUCCESS_200('查找成功', result);
  }
  
  @apiRequestMapping('get', '/wp/common/findListByKeyPrefix/:prefix')
  @pathParameter({ name: 'prefix', description: '前缀列表', type: 'string' })
  @apiDescription('获取所有指定前缀缓存Key列表')
  @get('/findListByKeyPrefix/:prefix')
  async findListByKeyPrefix(ctx) {
    ctx.log.resourceDesc = '获取所有指定前缀缓存Key列表';
    let result = cache.getKeys().filter(key => key.startsWith(ctx.params.prefix));
    ctx.body = statusCode.SUCCESS_200('查找成功', result);
  }
  
  @apiRequestMapping('get', '/wp/common/findCacheBaseInfo')
  @apiDescription('获取缓存信息')
  @get('/findCacheBaseInfo')
  async findCacheBaseInfo(ctx) {
    ctx.log.resourceDesc = '获取缓存信息';
    let result = {
      keyLength: cache.getKeys().length, // key的长度
      size: 0 // 缓存的大小
    };
    for (let key of cache.getKeys()) {
      let val = await cache.get(key);
      if (typeof val !== 'string') {
        val = JSON.stringify(val);
      }
      result.size += Buffer.from(val).length;
    }
    result.size = commonUtils.bytesToSize(result.size);
    ctx.body = statusCode.SUCCESS_200('查找成功', result);
  }
  
  @apiRequestMapping('post', '/wp/common/putCacheByKeyAndValue')
  @bodyParameter({ name: 'key', description: 'key值', required: true },
    { name: 'value', description: 'value值', required: true })
  @apiDescription('向缓存里加一条数据')
  @post('/putCacheByKeyAndValue')
  async putCacheByKey(ctx) {
    ctx.log.resourceDesc = '向缓存里加一条数据';
    let body = ctx.request.body;
    cache.put(body.key, body.value);
    let result = cache.get(body.key);
    ctx.body = statusCode.SUCCESS_200('追加成功', result);
  }

  @apiRequestMapping('get', '/wp/common/getWeChatId/:name')
  @pathParameter({ name: 'name', description: '花名', type: 'string' })
  @apiDescription('获取企业微信id')
  @get('/getWeChatId/:name')
  async getWeChatId(ctx) {
    ctx.log.resourceDesc = '获取企业微信id';
    let name = ctx.params.name;
    let result = await httpUtils.get(`http://10.1.1.16/hrweb/hr/getWxId/${encodeURI(name)}`);
    ctx.body = statusCode.SUCCESS_200('查找成功', result.data);
  }

}

