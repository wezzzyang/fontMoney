let systemDataDictionaryDO = {};
export { systemDataDictionaryDO }
export default function(sequelize, DataTypes) {
  const models = {
		id: {
			type: DataTypes.INTEGER(),
			allowNull: false,
			primaryKey: true,
			autoIncrement: true,
			field: 'id'
		},
		status: {
			type: DataTypes.INTEGER(),
			allowNull: false,
			defaultValue: 1,
			field: 'status'
		},
		createUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'create_user_id'
		},
		updateUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'update_user_id'
		},
		createTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'create_time'
		},
		updateTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'update_time'
		},
		code: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'code'
		},
		val: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'val'
		},
		desc: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'desc'
		},
		priority: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 0,
			field: 'priority'
		}
	};
  for(let key in models) {
    systemDataDictionaryDO[key] = '';
  }
  return sequelize.define('system_data_dictionary', models);
}
