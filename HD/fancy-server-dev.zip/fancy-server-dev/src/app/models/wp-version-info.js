let wpVersionInfoDO = {};
export { wpVersionInfoDO }
export default function(sequelize, DataTypes) {
  const models = {
		id: {
			type: DataTypes.INTEGER(),
			allowNull: false,
			primaryKey: true,
			autoIncrement: true,
			field: 'id'
		},
		status: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 1,
			field: 'status'
		},
		createUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'create_user_id'
		},
		updateUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'update_user_id'
		},
		createTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'create_time'
		},
		updateTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'update_time'
		},
		orgId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'org_id'
		},
		name: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'name'
		},
		startTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			field: 'start_time'
		},
		endTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			field: 'end_time'
		},
		notice: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'notice'
		},
		lifecycle: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'lifecycle'
		},
		primaryUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'primary_user_id'
		},
		primaryNickName: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'primary_nick_name'
		},
		milestoneId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'milestone_id'
		},
		versionLiveId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'version_live_id'
		},
		versionLifecycle: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'version_lifecycle'
		},
		isOpenDaily: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'is_open_daily'
		},
		belongSystem: {
		  type: DataTypes.STRING(),
		  allowNull: true,
		  field: 'belong_system'
		}
	};
  for(let key in models) {
    wpVersionInfoDO[key] = '';
  }
  return sequelize.define('wp_version_info', models);
}
