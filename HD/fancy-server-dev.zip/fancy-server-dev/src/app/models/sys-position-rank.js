let sysPositionRankDO = {};
export { sysPositionRankDO }
export default function(sequelize, DataTypes) {
  const models = {
		id: {
			type: DataTypes.INTEGER(),
			allowNull: false,
			primaryKey: true,
			autoIncrement: true,
			field: 'id'
		},
		status: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 1,
			field: 'status'
		},
		createUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'create_user_id'
		},
		updateUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'update_user_id'
		},
		createTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'create_time'
		},
		updateTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'update_time'
		},
		rankType: {
			type: DataTypes.STRING(),
			allowNull: true,
			field: 'rank_type'
		},
		bigRank: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'big_rank'
		},
		smallRank: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 0,
			field: 'small_rank'
		}
	};
  for(let key in models) {
    sysPositionRankDO[key] = '';
  }
  return sequelize.define('sys_position_rank', models);
}
