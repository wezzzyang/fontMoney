let sysDeptUserReleDO = {};
export { sysDeptUserReleDO }
export default function(sequelize, DataTypes) {
  const models = {
		id: {
			type: DataTypes.INTEGER(),
			allowNull: false,
			primaryKey: true,
			autoIncrement: true,
			field: 'id'
		},
		status: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 1,
			field: 'status'
		},
		createUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'create_user_id'
		},
		updateUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'update_user_id'
		},
		createTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'create_time'
		},
		updateTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'update_time'
		},
		userId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'user_id'
		},
		deptId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'dept_id'
		},
		isPrimary: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 0,
			field: 'is_primary'
		}
	};
  for(let key in models) {
    sysDeptUserReleDO[key] = '';
  }
  return sequelize.define('sys_dept_user_rele', models);
}
