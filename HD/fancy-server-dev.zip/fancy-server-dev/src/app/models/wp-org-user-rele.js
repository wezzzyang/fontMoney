let wpOrgUserReleDO = {};
export { wpOrgUserReleDO }
export default function(sequelize, DataTypes) {
  const models = {
		id: {
			type: DataTypes.INTEGER(),
			allowNull: false,
			primaryKey: true,
			autoIncrement: true,
			field: 'id'
		},
		status: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 1,
			field: 'status'
		},
		createUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'create_user_id'
		},
		updateUserId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'update_user_id'
		},
		createTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'create_time'
		},
		updateTime: {
			type: DataTypes.DATE(),
			allowNull: true,
			defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
			field: 'update_time'
		},
		orgId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'org_id'
		},
		userId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'user_id'
		},
		posiId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'posi_id'
		},
		posiRankId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'posi_rank_id'
		},
		isDefault: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			defaultValue: 1,
			field: 'is_default'
		},
		pPosiRankId: {
			type: DataTypes.INTEGER(),
			allowNull: true,
			field: 'p_posi_rank_id'
		}
	};
  for(let key in models) {
    wpOrgUserReleDO[key] = '';
  }
  return sequelize.define('wp_org_user_rele', models);
}
