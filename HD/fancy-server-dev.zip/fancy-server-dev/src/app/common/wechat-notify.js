/**
 * @idemon: 创建与 2020/01/14
 * @function: 发送企业微信
 */
import { server } from '../../config/rpc-config';

module.exports = {
  /**
   * 发送应用/群消息
   * @params {Object} messageObj 消息对象
   * @returns {Boolean} 是否发送成功
   */
  async sendMessage(messageObj) {
    let res = await server.sendMessage(messageObj);
    return res
  }
};
