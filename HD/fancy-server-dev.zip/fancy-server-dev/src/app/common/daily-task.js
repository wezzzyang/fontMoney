import { wpEnv } from '../../config/env-config.js';
const logsUtil = require('../../utils/logs');
const cron = require('node-cron');


/**
 * 定时任务启动函数
 * @returns {Promise<void>}
 */
async function main() {
  try {
    if (wpEnv.env === 'prod' || wpEnv.env === 'test') {
      // console.log('定时任务')
    }
  } catch (e) {
    logsUtil.daily(
      '[定时]启动异常报错，操作文件：daily-task.js' + JSON.stringify(e)
    );
  }
}
main();
