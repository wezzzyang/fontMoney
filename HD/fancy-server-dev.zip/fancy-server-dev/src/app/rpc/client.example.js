/**
 * Created by dy on 2020/7/21
 * 当前客户端调用其他服务案例
 */
import { server } from '../../config/rpc-config';


/**
 * 模拟调用外部方法
 * @returns {Promise<void>}
 */
async function test() {
  let { code, message, data } = await server.testRpc('测试调用');
  console.log({ code, message, data });
}

/**
 * 模拟监听外部广播
 * @returns {Promise<void>}
 */
async function test2() {
  // 参数: 广播主题，监听者ID，监听触发方法回调
  server.subscribe('wp-test', server.id, (data) => {
    console.log('监听调wp-test的回调', data);
  });
}
