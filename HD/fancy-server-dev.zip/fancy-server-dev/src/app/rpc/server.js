/**
 * Created by dy on 2020/7/20
 * 向外暴露RPC连接方法
 *
 * 说明：已提供暴露接口方法，后续将完善发布订阅
 * 使用说明：先引入rpc装饰器，系统会监听所有@rpc的方法，将其暴露出去
 */
import { rpc, publish } from '../../lib/router-permission';
import statusCode from '../../utils/status-code';

export class RpcServer {
  /**
   * 向外暴露调用方法
   * @param params 外部传入过来的参数
   * @param callback 返回给其他服务的回调方法
   */
  @rpc
  testRpc(params, callback) {
    console.log('成功调用:testRpc方法');
    callback(statusCode.SUCCESS_200('test', { list: [123, 23123, 123213213] }));
  }
  
  /**
   * @publish(topic[, ids]) topic 发布主题， ids 给指定ID推送数据
   * 设置发布主题名称，调用该方法将发布给所有订阅的客户端
   * @param data
   * @returns {string}
   */
  @publish('wp-test')
  async test(data) {
    return '阿杜测试调用' + data;
  }

}
// 测试发布订阅
// let rpcServer = new RpcServer();
// setInterval(() => {
//   rpcServer.test('模拟调用');
// }, 3000);


