import sysPositionRankDao from '../dao/sys-position-rank';
import { sysPositionRankDO } from '../models/sys-position-rank';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class SysPositionRankService extends BaseService{
  constructor() {
    super(sysPositionRankDao);
  }

}

export default new SysPositionRankService();