import authUserDao from '../dao/auth-user';
import { authUserDO } from '../models/auth-user';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
import cryptoUtils from '../../utils/crypto-utils';
import logUtil from '../../utils/logs';
const beanUtils = require('../../utils/bean-utils');
const jwt = require('jsonwebtoken');
const secret = require('../../config/secret');
const bcrypt = require('bcryptjs');

function packTokenByUser(user, password) {
  if (user == null || user === undefined) {
    throw statusCode.ERROR_403('用户不存在');
  }
  if (!user.password) {
    throw statusCode.ERROR_403('请点击使用青果统一登录方式进行登录');
  }
  if (!bcrypt.compareSync(password, user.password)) {
    throw statusCode.ERROR_403('用户名或密码错误');
  }
  user.password = '';
  const token = jwt.sign(user, secret.sign, { expiresIn: secret.tokenExpiresTime });
  return {
    id: user.id,
    username: user.username,
    nickName: user.nickName,
    avatar: user.avatar,
    token: token
  };
}
class AuthUserService extends BaseService {
  constructor() {
    super(authUserDao);
  }
  async handelToken(token) {
    return jwt.verify(token, secret.sign, function(err, decode) {
      return new Promise((resolve, reject)=> {
        if (err) {
          reject(err);
        } else {
          resolve(decode);
        }
      });
    });
  }
  // 把用户的权限信息封装到其中
  async packagePermissionByUser(userVO) {
    let userPerList = await authUserDao.findSqlByParamsToList(`
      select our.org_id, our.user_id, our.posi_id, sp.posi_name, sp.posi_group_id, pg.posi_group_name, sp.rank_type
      from wp_org_user_rele as our
      left join sys_position as sp
      on sp.id = our.posi_id and sp.status = 1
      left join sys_position_group as pg
      on sp.posi_group_id = pg.id and pg.status = 1
      where our.status = 1 and our.user_id = :userId ORDER BY org_id
    `, { userId: userVO.id });
    userPerList = beanUtils.camelCaseArrayObj(userPerList);
    let permissionInfo = {};
    userPerList.forEach(perDO => {
      let orgConfig = permissionInfo[perDO.orgId] || {};
      orgConfig.posiList = orgConfig.posiList || [];
      orgConfig.posiGroupList = orgConfig.posiGroupList || [];
      orgConfig.rankType = orgConfig.rankType || [];
      orgConfig.posiList.includes(perDO.posiName) || orgConfig.posiList.push(perDO.posiName);
      orgConfig.rankType.includes(perDO.rankType) || orgConfig.rankType.push(perDO.rankType);
      orgConfig.posiGroupList.includes(perDO.posiGroupName) || orgConfig.posiGroupList.push(perDO.posiGroupName);
      orgConfig.userId = userVO.id;
      orgConfig.orgId = perDO.orgId;
      permissionInfo[perDO.orgId] = orgConfig;
    });
    // 加密
    for (let orgId in permissionInfo) {
      // console.log('最终信息', permissionInfo[orgId]);
      permissionInfo[orgId].permissionHeader = cryptoUtils.symmetricCrypto(JSON.stringify(permissionInfo[orgId]));
    }
    userVO.permissionInfo = permissionInfo;
    let userDO = await authUserDao.findById(userVO.id);
    userVO.alias = userDO.alias;
    userVO.nickName = userDO.nickName;
    userVO.avatar = userDO.avatar;
    return userVO;
  }
  async loginNative(username, password) {
    // 判断用户是否存在 用户名
    let user;
    if ((user = await authUserDao.findByParam({ username: username, status: 1 })).length > 0) {
      return packTokenByUser(user[0], password);
    } else if ((user = await authUserDao.findByParam({ email: username, status: 1 })).length > 0) {
      return packTokenByUser(user[0], password);
    } else {
      throw statusCode.ERROR_403('用户不存在');
    }
  }
  async loginOther(token) {
    // 解析token
    const otherUser = await this.handelToken(token);
    // 判断 在本数据库中是否存在该用户
    let userList = await authUserDao.findSqlByParamsToList('select * from auth_user where status != 0 and source = 2 and username = :username', { username: otherUser.username });
    // 判断当前用户是否存在重复数据
    for (let user of userList) {
      if (user.status === 2) {
        logUtil.debug(`[统一登陆][离职用户尝试登陆]${user.id}|${user.username}|${user.nickName}|${user.alias}`);
        throw statusCode.ERROR_592('离职用户尝试登陆');
      }
    }
    let user = userList[0];
    let newToken;
    if (!user) {
      // 未在WP用户中，
      throw statusCode.ERROR_593('请联系管理员同步您的用户信息到WP中');
    }
    newToken = jwt.sign(user, secret.sign, { expiresIn: secret.tokenExpiresTime });
    return {
      id: user.id,
      username: user.username,
      nickName: user.nickName,
      avatar: user.avatar,
      alias: user.alias,
      token: newToken
    };
  }
  // 获取用户信息
  async getUserBaseById(userId) {
    let userDO = await this.getDevUserToken(userId);
    return this.packagePermissionByUser(userDO);
  }
  async getDevUserToken(id) {
    // 判断用户是否存在 用户名
    let user = await authUserDao.findById(id);
    if (!user) {
      throw statusCode.ERROR_403('用户不存在');
    }
    user.password = '';
    const token = jwt.sign(user, secret.sign, { expiresIn: secret.tokenExpiresTime });
    return {
      id: user.id,
      username: user.username,
      nickName: user.nickName,
      avatar: user.avatar,
      isNativeUser: user.source === 1,
      token: token
    };
  }
}

export default new AuthUserService();
