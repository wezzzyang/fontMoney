import sysDeptUserReleDao from '../dao/sys-dept-user-rele';
import { sysDeptUserReleDO } from '../models/sys-dept-user-rele';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class SysDeptUserReleService extends BaseService{
  constructor() {
    super(sysDeptUserReleDao);
  }

}

export default new SysDeptUserReleService();