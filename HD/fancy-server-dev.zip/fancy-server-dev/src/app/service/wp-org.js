import wpOrgDao from '../dao/wp-org';
import { wpOrgDO } from '../models/wp-org';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class WpOrgService extends BaseService {
  constructor() {
    super(wpOrgDao);
  }
  // 获取项目组信息
  async getOrgBaseById(orgId) {
    let orgDO = await wpOrgDao.findSqlByParamsToOne(`
      select a.id, a.name, a.name_code, string_agg(b.url, '，') as svn_addr, string_agg(c.url, '，') as git_addr,
        case when a.is_open_report is null then 0 else a.is_open_report end as is_open_report
      from wp_org a
      left join wp_warehouse_config b
      on a.id=b.org_id and b.type='svn' and b.status=1
      left join wp_warehouse_config c
      on a.id=c.org_id and c.type='git' and c.status=1
      where a.id=:orgId
      group by a.id, a.name, a.name_code, a.is_open_report
    `, { orgId });
    orgDO = beanUtils.camelCaseyObj(orgDO);
    return orgDO;
  }
  async getProjectUserConfig(orgId) {
    let result = {};
    let list = await wpOrgDao.findSqlByParamsToList(`select e.id,e.nick_name || '(' || e."alias" || ')' as name,
                case
                  when d.posi_name='项目经理' then 'pm'
                  when d.posi_name='制作人' then 'pd'
                  when d.posi_name='主策划' then 'plm'
                  when d.posi_name='主技术' then 'tm'
                  when d.posi_name='主艺术' then 'am'
                  when d.posi_name like '%小组长' then 'amg'
                  when d.posi_name='主质量' then 'qm'
                  ELSE 'p'
                end
                as type
                from wp_org b
                left join wp_org_user_rele c
                on b.id=c.org_id
                left join sys_position d
                on c.posi_id=d.id
                left join auth_user e
                on c.user_id=e.id
                where e.status=1 and c.status = 1 and b.id= :orgId
								ORDER BY type`, { orgId });
    list.forEach(item => {
      if (!result[item.type]) {
        result[item.type] = [];
      }
      result[item.type].push(item);
    });
    return result;
  }
}

export default new WpOrgService();
