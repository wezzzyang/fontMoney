import sysDeptDao from '../dao/sys-dept';
import { sysDeptDO } from '../models/sys-dept';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class SysDeptService extends BaseService{
  constructor() {
    super(sysDeptDao);
  }

}

export default new SysDeptService();
