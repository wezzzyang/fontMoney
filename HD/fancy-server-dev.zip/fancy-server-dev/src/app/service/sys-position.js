import sysPositionDao from '../dao/sys-position';
import { sysPositionDO } from '../models/sys-position';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class SysPositionService extends BaseService{
  constructor() {
    super(sysPositionDao);
  }

}

export default new SysPositionService();