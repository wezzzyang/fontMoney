import sysPositionGroupDao from '../dao/sys-position-group';
import { sysPositionGroupDO } from '../models/sys-position-group';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class SysPositionGroupService extends BaseService{
  constructor() {
    super(sysPositionGroupDao);
  }

}

export default new SysPositionGroupService();