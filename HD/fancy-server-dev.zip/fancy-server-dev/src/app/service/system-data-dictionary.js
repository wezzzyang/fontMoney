import systemDataDictionaryDao from '../dao/system-data-dictionary';
import { systemDataDictionaryDO } from '../models/system-data-dictionary';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class SystemDataDictionaryService extends BaseService{
  constructor() {
    super(systemDataDictionaryDao);
  }

}

export default new SystemDataDictionaryService();