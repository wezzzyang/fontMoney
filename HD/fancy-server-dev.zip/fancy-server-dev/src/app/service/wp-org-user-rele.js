import wpOrgUserReleDao from '../dao/wp-org-user-rele';
import { wpOrgUserReleDO } from '../models/wp-org-user-rele';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class WpOrgUserReleService extends BaseService{
  constructor() {
    super(wpOrgUserReleDao);
  }

}

export default new WpOrgUserReleService();