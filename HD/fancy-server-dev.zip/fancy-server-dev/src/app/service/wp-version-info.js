import wpVersionInfoDao from '../dao/wp-version-info';
import wpMilestoneDao from '../dao/wp-milestone';
import { wpVersionInfoDO } from '../models/wp-version-info';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class WpVersionInfoService extends BaseService{
  constructor() {
    super(wpVersionInfoDao);
  }
  async getVersionBaseById(versionId) {
    return wpVersionInfoDao.findSqlByParamsToOne(`select id,name,belong_system,org_id from wp_version_info where id = :versionId`, { versionId });
  }
  async findMilestoneAndVersionByCascader(orgId) {
    let result = [], middleMap = new Map();
    let list = await wpMilestoneDao.findSqlByParamsToList(`select wvi.id,wvi.belong_system,wvi.status,wvi.name,wvi.create_time, wm.id as milestone_id,wm.name as milestone_name,wm.code, wm.pid as milestone_pid
      from wp_milestone as wm
      left join wp_version_info as wvi
      on wvi.milestone_id = wm.id and wvi.status != 0 and wvi.org_id = :orgId
			where wm.org_id = 0 or wm.org_id = :orgId
      ORDER BY wm.id, wvi.id `, { orgId });
    for (let versionObj of list) {
      let middleObj = {
        id: versionObj.milestone_id,
        label: versionObj.milestone_name,
        pid: versionObj.milestone_pid,
        belongSystem: versionObj.belong_system,
        code: versionObj.code,
        childList: []
      };
      if (!middleMap.has(versionObj.milestone_id)) {
        middleMap.set(versionObj.milestone_id, middleObj);
      } else {
        middleObj = middleMap.get(versionObj.milestone_id);
      }
      if (!versionObj.id) {
        middleObj.childList = undefined;
        continue;
      }
      middleObj.childList.push({
        id: versionObj.id,
        label: versionObj.name,
        code: 'version'
      });
    }
    result = [...middleMap.values()];
    return result.filter(father => {
      const branchArr = result.filter(child => father.id === child.pid);
      if (branchArr.length > 0) {
        father.childList = branchArr;
      }
      return father.pid === 0;
    });
  }
}

export default new WpVersionInfoService();
