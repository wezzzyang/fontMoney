import sysUserInfoDao from '../dao/sys-user-info';
import { sysUserInfoDO } from '../models/sys-user-info';
import BaseService from '../../lib/base-service';
import statusCode from '../../utils/status-code';
const beanUtils = require('../../utils/bean-utils');
class SysUserInfoService extends BaseService{
  constructor() {
    super(sysUserInfoDao);
  }

}

export default new SysUserInfoService();