/**
 * Created by dy on 2020/7/20
 */
const hprose = require('hprose');
const { wpEnv, getSysConfig } = require('./env-config');
const beanUtils = require('../utils/bean-utils');

const PREFIX_INI = 'rpc_';
const URI_JOIN = ',';
const setting = getSysConfig(wpEnv.env);
let rpcConfigKeys = Object.keys(setting).filter(key => key.startsWith(PREFIX_INI));


let rpcClient = {};
for (let key of rpcConfigKeys) {
  let clientName = beanUtils.camelCase(key.substring(PREFIX_INI.length));
  setting[key].clientName = clientName;
  let uri = setting[key].uri;
  if (uri.includes(URI_JOIN)) {
    uri = uri.split(URI_JOIN);
  }
  let client = new hprose.HttpClient(uri, null, { timeout: (setting[key].timeout && +setting[key].timeout) || 20000 });
  let get = (target, propKey)=> {
    if (propKey in target) {
      return target[propKey];
    }
    if (['subscribe'].includes(propKey)) {
      return client[propKey];
    }
    return (data) => {
      return new Promise((resolve, reject) => {
        client.ready((proxy) => {
          proxy[propKey](data, (result) => {
            resolve(result);
          }, (name, error) => {
            reject({ name, error });
          });
        });
      });
    };
  };
  rpcClient[clientName] = new Proxy(setting[key], { get });
  console.info(`已成功注册RPC连接：${clientName}`);
}

module.exports = rpcClient;
