const dbConfig = require('./env-config').dbConfig;
const pg = require('pg');
const conStr = `postgres://${dbConfig.dbUser}:${dbConfig.password}@${dbConfig.dbHost}:${dbConfig.dbPort}/${dbConfig.dbName}`;

const ddlFunctionArr = [];

function pgSqlOne(client, sql) {
  return new Promise((resolve, reject)=> {
    client.query(sql, [], function(isErr, rst) {
      console.log('当前指定sql语句为：', sql);
      if (isErr) {
        console.error('操作失败:' + isErr.message);
        resolve(isErr);
      } else {
        console.log('操作成功, data is: ' + JSON.stringify(rst));
        resolve(rst);
      }
    });
  });
}

async function pgExecuteSql(client, sqlArr) {
  return new Promise((resolve, reject)=> {
    client.connect(function(isErr) {
      if (isErr) {
        console.error('connect error:' + isErr.message);
        client.end();
      }
      const resultArr = [];
      for (let i = 0; i < sqlArr.length; i++) {
        pgSqlOne(client, sqlArr[i]).then(result => {
          resultArr.push(result);
          if (i === sqlArr.length - 1) {
            resolve(resultArr);
            return;
          }
          pgSqlOne(client, sqlArr[i]);
        });
      }
    });
  });
}


module.exports = {
  updateDDL: async(isUpdate) => {
    if (!isUpdate || ddlFunctionArr.length === 0) {
      console.log('以关闭自动更新数据库代码 或 暂无可更新sql语句');
      return;
    }
    const version = ddlFunctionArr.length - 1;
    let client = new pg.Client(conStr);
    // 判断是否执行
    let executeSqlBool = false;
    const waitExecuteSql = [];
    const dbVer = await pgExecuteSql(client, ['select * from db_update_version where id = 1']);
    client.end();
    if (dbVer[0].code === '42P01') {
      // 表示没有版本号表-需要更新sql
      executeSqlBool = true;
      waitExecuteSql.push('CREATE TABLE "public"."db_update_version" ("id" int4 primary key,"version" int4,"create_time" timestamp(6))');
      waitExecuteSql.push('insert into db_update_version values (1,1,current_timestamp)');
    } else {
      // 表示存在历史版本号 - 判断版本号与当前版本号是否相同，相同则不执行，不同则执行
      executeSqlBool = dbVer[0].rows[0].version === version;
      console.log('存在历史版本，当前版本号为：' + dbVer[0].rows[0].version + ',最新版本号为：' + version);
    }
    console.log('是否执行更新代码：' + executeSqlBool);
    if (executeSqlBool) {
      return;
    }
    client = new pg.Client(conStr);
    // 执行DDL
    console.log('执行了DDL');
    // 设置当前版本号
    console.log(ddlFunctionArr[version](waitExecuteSql));
    const resultArr = await pgExecuteSql(client, waitExecuteSql);
    console.log('!!!!!!!!!!!!! 执行结束', resultArr);
    client.end();
    client = new pg.Client(conStr);
    await pgExecuteSql(client, [`update db_update_version set version = ${version},create_time=current_timestamp  where id = 1`]);
    client.end();
  }
};



