const path = require('path');
// const envConfig = require('./env-config.js');
// const wpEnv = envConfig.wpEnv;
//日志根目录
let baseLogPath = path.resolve(__dirname, '../../logs');
// const baseLogPath = wpEnv.logsPath;
// 日志模块配置数组
const logArg = ['debug', 'wp', 'daily', 'job', 'notify'];

let configure = {
  pm2: true,
  // pm2InstanceVar: 'WP_V1_APP',
  //日志格式等设置
  appenders: {
    'rule-console': { 'type': 'console' },
    'errorLogger': {
      'type': 'dateFile',
      'filename': `${baseLogPath}/error/error`,
      'pattern': 'yyyy-MM-dd.log',
      'alwaysIncludePattern': true,
      'encoding': 'utf-8',
      'maxLogSize': 10485760, // 单个文件大小
      'backups': 3, // 单个文件备份数量
      'path': `${baseLogPath}/error/error`
    }
  },
  //供外部调用的名称和对应设置定义
  categories: {
    'default': { 'appenders': ['rule-console'], 'level': 'all' },
    'errorLogger': { 'appenders': ['errorLogger'], 'level': 'ERROR' }
  },
  'baseLogPath': baseLogPath
};

for (let name of logArg) {
  configure.appenders[`${name}Logger`] = {
    'type': 'dateFile',
    'filename': `${baseLogPath}/${name}/${name}`,
    'pattern': 'yyyy-MM-dd.log',
    'alwaysIncludePattern': true,
    'encoding': 'utf-8',
    'maxLogSize': 10485760, // 单个文件大小
    'backups': 3, // 单个文件备份数量
    'path': `${baseLogPath}/${name}/${name}`
  };
  configure.categories[`${name}Logger`] = { 'appenders': [`${name}Logger`], 'level': 'info' };
}
module.exports = {
  configure,
  logArg
};
