/*
 * @Author: 付汩
 * @Date: 2020-07-20 14:31:18
 * @LastEditors: 付汩
 * @LastEditTime: 2020-08-07 16:00:37
 * @email: fuxueshuang@fancyguo.cn
 */ 
const fs = require('fs');
const ini = require('ini');
const path = require('path');
const address = require('address');
const os = require('os');

const _config_ = {
  getIPAdress: () => { // 获取当前ip地址
    return address.ip();
  },
  getSystem: ()=>{ // 获取操作系统 Linux || startsWith('Windows')
    return os.type();
  },
  getSysConfig(env) { // 加载系统配置 dev | prod | test
    const iopath = path.join(__dirname, `../../settings/${env}.ini`);
    const res = ini.parse(fs.readFileSync(iopath, 'utf-8'));
    return res;
  },
  getEnvType() { // 获取env类型
    let env = 'dev';
    switch (process.env.NODE_ENV) {
      case 'production': // 正式环境
        env = 'prod';
        break;
      case 'beta': // 测试环境
        env = 'test';
        break;
      default: // 开发环境
        env = 'dev';
        break;
    }
    return env;
  }
};

// 获取env对象
function getEnvConfig() {
  const env = _config_.getEnvType();
  const ipAdress = _config_.getIPAdress(); // 获取IP地址
  const sysConfig = _config_.getSysConfig(env); // 获取配置信息
  const projectName = sysConfig.projectName ? sysConfig.projectName : 'moren';
  let envConfig = {
    env: env, // 当前环境
    projectName: projectName, // 项目名称
    localIp: ipAdress, // 本地ip
    port: 8621, // 服务端口号
    loginIp: '', // 登录url地址
    reqProtocol: '', // 请求协议
    ddlUpdatD: true, // 是否开启数据库自动更新代码
    logsPath: '', // log地址
    logsClearTime: 7, // 只保留7日内的日志
    uploadUrl: '', // 读取资源url
    uploadDir: '', // 上传系统地址
    imageDir: '', // 图片存放的系统地址
    videoDir: '', // 视频存放的系统地址
    tmpDir: '', // 模板上传的系统地址
    svnWorkPath: '' // svn工作目录
  };
  envConfig = Object.assign(envConfig, { ...sysConfig.view, ...sysConfig.serve, ...sysConfig.log, ...sysConfig.fileUrl });
  for (let dir of ['imageDir', 'uploadDir', 'videoDir', 'tmpDir', 'uploadUrl']) {
    envConfig[dir] = `${envConfig[dir]}/${projectName}`;
  }
  // 单独处理登陆url地址
  return envConfig;
}

// 获取db配置
function getDBConfig() {
  const env = _config_.getEnvType();
  const sysConfig = _config_.getSysConfig(env); // 获取配置信息
  let dbConfig = {
    dbHost: '',
    dbPort: '',
    dbUser: '',
    dbPassword: '',
    dbName: ''
  };
  dbConfig = Object.assign(dbConfig, sysConfig.db);
  return dbConfig;
}

module.exports = {
  packageEnv: function() {
    return async function(ctx, next) {
      ctx.wpEnv = { ...getEnvConfig() };
      await next();
    };
  },
  wpEnv: getEnvConfig(),
  dbConfig: getDBConfig(),
  getSysConfig: _config_.getSysConfig
};
