const Sequelize = require('sequelize');
const dbConfig = require('./env-config').dbConfig;
const config = {
  host: dbConfig.dbHost,
  password: dbConfig.dbPassword,
  user: dbConfig.dbUser,
  database: dbConfig.dbName,
  port: dbConfig.dbPort,
  dialect: 'postgres',
  // 扩展属性
  idle: 10000, // 连接在释放之前可以空闲的最长时间（以毫秒为单位）。
  acquire: 30000, // 池抛出错误之前尝试获取连接的最长时间（以毫秒为单位）
  max: 5, // 连接池最大连接数 - 30
  min: 0 // 连接池最小连接数
};

export const dbSequelize = new Sequelize(config.database, config.user, config.password, {
  host: config.host,
  port: config.port,
  dialect: config.dialect,
  timezone: '+08:00', //东八时区 - 不然会相差8小时
  define: {
    // 取消orm框架自动添加时间戳
    timestamps: false,
    charset: 'utf8',
    // 取消创建表名复数形式
    freezeTableName: true,
    // 字段以下划线（_）来分割（默认是驼峰命名风格）
    'underscored': true
  },
  pool: {
    max: config.max,
    min: config.min,
    acquire: config.acquire,
    idle: config.idle
  },
  logging: () => {
  }
});
