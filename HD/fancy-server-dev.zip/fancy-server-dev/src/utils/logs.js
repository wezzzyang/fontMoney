const log4js = require('log4js');
const logsConfig = require('../config/logs-config.js');
//加载配置文件
log4js.configure(logsConfig.configure);
//调用预先定义的日志名称
const errorLogger = log4js.getLogger('errorLogger');
const envConfig = require('../config/env-config.js');
const wpEnv = envConfig.wpEnv;

let logMap = new Map();
for (let name of logsConfig.logArg) {
  logMap.set(name, log4js.getLogger(`${name}Logger`));
}


// 格式化日志文本 加上日志头尾和换行方便查看 ==>  普通日志、请求日志、响应日志、操作日志、错误日志
const formatText = {
  error: function(ctx, err, resTime) {
    let logText = '';
    //错误信息开始
    logText += '\n' + '*************** error log start ***************' + '\n';
    //添加请求日志
    // logText += formatText.request(ctx.request, resTime);
    //错误名称
    logText += 'err name: ' + err.name + '\n';
    //错误信息
    logText += 'err message: ' + err.message + '\n';
    //错误详情
    logText += 'err stack: ' + err.stack + '\n';
    //错误信息结束
    logText += '*************** error log end ***************' + '\n';
    return logText;
  },
  request: function(req, resTime) {
    let logText = '';
    const method = req.method;
    //访问方法
    logText += 'request method: ' + method + '\n';
    //请求原始地址
    logText += 'request originalUrl:  ' + req.originalUrl + '\n';
    //客户端ip
    logText += 'request client ip:  ' + req.ip + '\n';
    //开始时间
    // let startTime;
    //请求参数
    if (method === 'GET') {
      logText += 'request query:  ' + JSON.stringify(req.query) + '\n';
      // startTime = req.query.requestStartTime;
    } else {
      logText += 'request body: ' + '\n' + JSON.stringify(req.body) + '\n';
      // startTime = req.body.requestStartTime;
    }
    //服务器响应时间
    logText += 'response time: ' + resTime + '\n';
    return logText;
  }
};

let logFun = {
  info: function(type, logInfo) {
    if (!logMap.has(type)) {
      errorLogger.error('当前日志输出类型不存在');
      return;
    }
    logMap.get(type) && logMap.get(type).info(logInfo);
  },
  //封装错误日志
  error: function(ctx, error, resTime) {
    if (ctx && error) {
      errorLogger.info(formatText.error(ctx, error, resTime));
    }
  },
  //debug日志
  debug: (logInfo) => logMap.get('debug').info(logInfo),
  wp: (logInfo) => logMap.get('wp').info(logInfo),
  daily: (logInfo) => logMap.get('daily').info(logInfo),
  job: (logInfo) => logMap.get('job').info(logInfo),
  notify: (logInfo) => logMap.get('notify').info(logInfo),
  // todo:定期清除日志
  autoClearLogFiles: function() {
    // logsClearTime - logsPath
  }
};
// 获取扩展放开
// for (let name of logsConfig.logArg) {
//   logFun[name] = (logInfo) => logMap.get(name).info(logInfo);
// }
module.exports = logFun;
