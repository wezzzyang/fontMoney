/*
 * @Author: 付汩
 * @Date: 2019-11-26 11:14:37
 * @LastEditors: 付汩
 * @LastEditTime: 2019-12-03 14:25:00
 * @email: fuxueshuang@fancyguo.cn
 * @description: 用于编写原生sql
 */
import { dbSequelize } from '../config';

const fetchallParameter = {
  type: dbSequelize.QueryTypes.SELECT,
  plain: false,
  raw: true
};
const fetchoneParameter = {
  type: dbSequelize.QueryTypes.SELECT,
  plain: true,
  raw: true
};
module.exports = {
  // 执行sql查询语句，返回数组对象
  __fetchall: function(sql) {
    return new Promise((resolve) => {
      dbSequelize
        .query(sql, fetchallParameter)
        .then((results) => {
          if (results) {
            resolve(results);
          } else {
            resolve([]);
          }
        });
    });
  },
  __fetchone: function(sql) {
    return new Promise((resolve) => {
      dbSequelize
        .query(sql, fetchoneParameter)
        .then((results) => {
          if (results) {
            resolve(results);
          } else {
            resolve({});
          }
        });
    });
  }
};
