/*
 * @Author: 付汩
 * @Date: 2019-11-26 11:14:37
 * @LastEditors: 付汩
 * @LastEditTime: 2020-05-30 12:49:04
 * @email: fuxueshuang@fancyguo.cn
 * @description: 基于原生sql的表格翻页、排序、筛选、模糊搜索配置
 * @param {
      filters: { source: ['1'], personid: ['1'] }, // 过滤
      pagination: { current: 1, pageSize: 10 }, // 翻页
      search: { value: '搜索' }, // 模糊搜索
      sorter: { field: 'id', order: 'asc' } // 排序
    }
 */

import dbquery from './db_query';

export default class parseTable {
  constructor(params, searchConfig) {
    // this.params = params;
    this.pagination = params.pagination ? params.pagination : {}; // 翻页
    this.filters = params.filters ? params.filters : {}; // 过滤
    this.sorter = params.sorter ? params.sorter : {}; // 排序
    this.search = params.search ? params.search : {}; // 模糊搜索
    this._result_ = ''; // 最终的结果
    this.searchConfig = searchConfig ? searchConfig : []; // 模糊查询序列
  }
  // 初始化
  init(param) {
    this._result_ = `select * from (${param}) a`;
    return this;
  }
  // 获取SQL
  getSql() {
    return this._result_;
  }
  // 请求数据库-多条
  async asyncQueryAll() {
    return await dbquery.__fetchall(this._result_);
  }
  // 请求数据库-单条
  async asyncQueryOne() {
    return await dbquery.__fetchone(this._result_);
  }
  // 获取条数L
  async asyncGetCount() {
    let res = await dbquery.__fetchone(`select count(1) from (${this._result_}) a`);
    return Number(res.count);
  }
  // 偏移量
  offset() {
    try {
      this._result_ += ` offset ${(this.pagination['current'] - 1) * this.pagination['pageSize']}`;
    } catch {
      this._result_ += ' offset 0';
    }
    return this;
  }
  // 页面大小
  limit() {
    try {
      this._result_ += ` limit ${this.pagination['pageSize']}`;
    } catch {
      // this._result_ += ' limit 10';
    }
    return this;
  }
  // 排序
  orderBy() {
    try {
      this._result_ += this.sorter ? ` order by a.${this.sorter['field']} ${this.sorter['order']}` : '';
    } catch {
      this._result_ += '';
    }
    return this;
  }
  // 筛选模糊搜索
  where() {
    try {
      let searchSql = [];
      let _whereSql_ = '';
      if (this.search.value && this.searchConfig && this.searchConfig.length > 0) {
        this.searchConfig.forEach(config => {
          searchSql.push(`a.${config} like '%${this.search.value}%'`);
        });
      }
      let filterSql = [];
      for (const [key, value] of Object.entries(this.filters)) {
        let filterVal = [];
        if (Number(value.length) === 0) continue;
        value.forEach((item)=>{filterVal.push(`'${item}'`);});
        filterSql.push(`a.${key}::text in (${filterVal.join(',')})`);
      }
      if (searchSql.length > 0) {
        _whereSql_ += searchSql.join(' or ');
      }
      if (filterSql.length > 0) {
        _whereSql_ += _whereSql_.length > 0 ? ` and ${filterSql.join(' and ')}` : `${filterSql.join(' and ')}`;
      }
      if (_whereSql_.trim()) this._result_ += ` where ${_whereSql_}`;
    } catch {
      this._result_ += '';
    }
    return this;
  }
}
