const htmlDocx = require('html-docx-js');

module.exports = {
  analysisHtml
};

async function analysisHtml(textHtml) {
  return htmlDocx.asBlob(textHtml);
}

