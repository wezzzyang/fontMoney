
const Koa = require('koa');
const app = new Koa();
const json = require('koa-json');
const bodyparser = require('koa-bodyparser');

import { packageEnv, wpEnv } from './config/env-config';
import dayjs from 'dayjs';
import weekOfYear from 'dayjs/plugin/weekOfYear';
app.use(json());
app.use(bodyparser({
  enableTypes: ['json', 'form', 'text'],
  'jsonLimit': '30mb'
}));
dayjs.extend(weekOfYear);
// 加载配置
app.use(packageEnv());

// 挂载全部的中间件
require('./middleware')(app);
// 更新数据库，每次程序启动的时候进行
const updateDDL = require('./config/update-ddl.js');
updateDDL.updateDDL(wpEnv.ddlUpdate);
require('./app/common/daily-task');
app.listen(wpEnv.port, () => {
  console.info(`服务已经启动, 后端地址:${wpEnv.reqProtocol}://${wpEnv.localIp}:${wpEnv.port}`);
  console.info(`swagger-api文档地址:${wpEnv.reqProtocol}://${wpEnv.localIp}:${wpEnv.port}/swagger`);
  console.info(`--------------------注意此项目为微服务子系统模板-------------------`);
});
