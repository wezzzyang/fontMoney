require('@babel/register');
require('@babel/polyfill');

// 这个是引入启动文件
require('./src/index');
